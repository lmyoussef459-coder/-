#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
استخدم هذا الملف بعد نشر الموقع ومعرفة رابطه الحقيقي.
مثال التشغيل:
    python3 set-domain.py https://my-zodiac-site.netlify.app

سيستبدل هذا تلقائياً الرابط المؤقت في كل ملفات HTML وملف sitemap.xml وrobots.txt.
"""
import sys, os, glob

OLD = "https://REPLACE-WITH-YOUR-DOMAIN.com"

def main():
    if len(sys.argv) != 2:
        print("الاستخدام: python3 set-domain.py https://your-real-domain.com")
        sys.exit(1)
    new_domain = sys.argv[1].rstrip("/")
    here = os.path.dirname(os.path.abspath(__file__))
    changed = 0
    for path in glob.glob(os.path.join(here, "*.html")) + \
                glob.glob(os.path.join(here, "*.xml")) + \
                glob.glob(os.path.join(here, "*.txt")):
        with open(path, encoding="utf-8") as f:
            content = f.read()
        if OLD in content:
            content = content.replace(OLD, new_domain)
            with open(path, "w", encoding="utf-8") as f:
                f.write(content)
            changed += 1
            print(f"✅ تم التحديث: {os.path.basename(path)}")
    print(f"\nتم استبدال الرابط في {changed} ملف. رابطك الجديد: {new_domain}")

if __name__ == "__main__":
    main()
