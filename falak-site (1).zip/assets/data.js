// بيانات الأبراج المشتركة — تُستخدم في أدوات الحاسبة التفاعلية
const ZODIAC = [
  { slug:"aries", name:"الحمل", element:"fire", start:[3,21], end:[4,19], quality:"cardinal" },
  { slug:"taurus", name:"الثور", element:"earth", start:[4,20], end:[5,20], quality:"fixed" },
  { slug:"gemini", name:"الجوزاء", element:"air", start:[5,21], end:[6,20], quality:"mutable" },
  { slug:"cancer", name:"السرطان", element:"water", start:[6,21], end:[7,22], quality:"cardinal" },
  { slug:"leo", name:"الأسد", element:"fire", start:[7,23], end:[8,22], quality:"fixed" },
  { slug:"virgo", name:"العذراء", element:"earth", start:[8,23], end:[9,22], quality:"mutable" },
  { slug:"libra", name:"الميزان", element:"air", start:[9,23], end:[10,22], quality:"cardinal" },
  { slug:"scorpio", name:"العقرب", element:"water", start:[10,23], end:[11,21], quality:"fixed" },
  { slug:"sagittarius", name:"القوس", element:"fire", start:[11,22], end:[12,21], quality:"mutable" },
  { slug:"capricorn", name:"الجدي", element:"earth", start:[12,22], end:[1,19], quality:"cardinal" },
  { slug:"aquarius", name:"الدلو", element:"air", start:[1,20], end:[2,18], quality:"fixed" },
  { slug:"pisces", name:"الحوت", element:"water", start:[2,19], end:[3,20], quality:"mutable" },
];

const ELEMENT_COLOR = { fire:"#bd5730", earth:"#6d7c40", air:"#2c7078", water:"#3c5286" };
const ELEMENT_NAME = { fire:"النار", earth:"التراب", air:"الهواء", water:"الماء" };

// مسارات SVG لكل برج (نفس رسومات zodiac_icons.py) — بديل موثوق عن رموز يونيكود
// التي تحوّلها بعض الأنظمة تلقائياً لأيقونات إيموجي ملوّنة بغض النظر عن الخط.
const ZODIAC_PATHS = {
  aries: '<path d="M16,25 C16,18 10.5,18 10.5,12 C10.5,9 12.5,7.5 15,8.5"/><path d="M16,25 C16,18 21.5,18 21.5,12 C21.5,9 19.5,7.5 17,8.5"/>',
  taurus: '<circle cx="16" cy="21" r="6"/><path d="M10.5,15 C9,10 11,7 14.5,8"/><path d="M21.5,15 C23,10 21,7 17.5,8"/>',
  gemini: '<line x1="8" y1="8" x2="24" y2="8"/><line x1="8" y1="24" x2="24" y2="24"/><line x1="12" y1="8" x2="12" y2="24"/><line x1="20" y1="8" x2="20" y2="24"/>',
  cancer: '<circle cx="10.5" cy="12" r="3"/><path d="M10.5,15 C10.5,22 21.5,10 21.5,17"/><circle cx="21.5" cy="20" r="3"/>',
  leo: '<circle cx="12.5" cy="19.5" r="5.3"/><path d="M12.5,14.2 C12.5,8.5 18.5,7.5 20,11 C21.3,14 18.7,15.5 20.3,18"/>',
  virgo: '<path d="M8,8 L8,23"/><path d="M8,8 C8,8 12.5,20 13,10"/><path d="M13,10 C13,10 17.5,20 18,10"/><path d="M18,10 C18,18 23,16 23,20 C23,23 19.5,23 19.5,20"/>',
  libra: '<path d="M8,14 C8,9.5 24,9.5 24,14"/><line x1="6" y1="22" x2="26" y2="22"/>',
  scorpio: '<path d="M8,8 L8,23"/><path d="M8,8 C8,8 12.5,20 13,10"/><path d="M13,10 C13,10 17.5,22 17.5,10"/><path d="M17.5,15 L23,21"/><path d="M23,21 L23,16.5"/><path d="M23,21 L18.5,21"/>',
  sagittarius: '<line x1="7" y1="25" x2="24" y2="8"/><path d="M24,8 L16.5,8"/><path d="M24,8 L24,15.5"/><line x1="13.5" y1="14.5" x2="17.5" y2="18.5"/>',
  capricorn: '<path d="M8,9 L13,22 L18,9"/><path d="M18,9 L18,19 C18,23.5 23.5,23.5 23.5,19.5 C23.5,17 20.5,17 20.5,19"/>',
  aquarius: '<path d="M5.5,12.5 L9.5,9.5 L13.5,15.5 L17.5,9.5 L21.5,15.5 L25.5,12.5"/><path d="M5.5,20.5 L9.5,17.5 L13.5,23.5 L17.5,17.5 L21.5,23.5 L25.5,20.5"/>',
  pisces: '<path d="M11.5,7 C6.5,11 6.5,21 11.5,25"/><path d="M20.5,7 C25.5,11 25.5,21 20.5,25"/><line x1="7" y1="16" x2="25" y2="16"/>',
};

function zodiacIconSvg(slug, size) {
  size = size || 34;
  const inner = ZODIAC_PATHS[slug] || "";
  return `<svg class="zodiac-icon" width="${size}" height="${size}" viewBox="0 0 32 32" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true">${inner}</svg>`;
}

function findSignByDate(month, day) {
  for (const s of ZODIAC) {
    const [sm, sd] = s.start, [em, ed] = s.end;
    if (sm > em) { // يمتد عبر نهاية السنة (الجدي)
      if ((month === sm && day >= sd) || (month === em && day <= ed)) return s;
    } else {
      if ((month === sm && day >= sd) || (month === em && day <= ed) || (month > sm && month < em)) return s;
    }
  }
  return null;
}

function signBySlug(slug) { return ZODIAC.find(s => s.slug === slug) || null; }
