// ===== أبراج وشهور — التفاعلات المشتركة =====
document.addEventListener("DOMContentLoaded", () => {
  initStarfield();
  initNav();
  initElementColors();
  initFlipCards();
  initTilt();
  initReveal();
  initFinder();
  initCompat();
  initFaq();
  initWheelFallback();
  initSmoothAnchors();
});

/* ---------- تمرير سلس للروابط الداخلية (لا يعتمد على سلوك المتصفح الافتراضي) ---------- */
function initSmoothAnchors() {
  document.querySelectorAll('a[href^="#"]').forEach(link => {
    const id = link.getAttribute("href").slice(1);
    if (!id) return;
    link.addEventListener("click", (e) => {
      const target = document.getElementById(id);
      if (!target) return; // اترك السلوك الافتراضي إن لم يوجد هدف بنفس الصفحة
      e.preventDefault();
      target.scrollIntoView({ behavior: "smooth", block: "start" });
    });
  });
}

/* ---------- العجلة ثلاثية الأبعاد: احتياط عند فشل التحميل ---------- */
function initWheelFallback() {
  const mv = document.getElementById("zodiacModel");
  const fallback = document.getElementById("wheelFallback");
  if (!mv || !fallback) return;
  let resolved = false;

  function showFallback() {
    if (resolved) return;
    resolved = true;
    mv.style.display = "none";
    fallback.classList.add("show");
  }
  function markLoaded() { resolved = true; }

  // إن لم يُعرَّف عنصر model-viewer أصلاً (فشل تحميل السكربت)، لن تُطلق أي أحداث — المؤقّت هو الشبكة الأخيرة
  mv.addEventListener("load", markLoaded);
  mv.addEventListener("error", showFallback);
  setTimeout(() => { if (!resolved) showFallback(); }, 4500);
}

/* ---------- خريطة الأبراج الخلفية (نقاط حبر وخطوط توصيل، بلا توهج) ---------- */
function initStarfield() {
  const canvas = document.getElementById("starfield");
  if (!canvas) return;
  const ctx = canvas.getContext("2d");
  let w, h, points;

  function resize() {
    w = canvas.width = window.innerWidth;
    h = canvas.height = Math.max(window.innerHeight, document.body.scrollHeight);
    const count = Math.round((w * h) / 26000);
    points = Array.from({ length: Math.min(count, 90) }, () => ({
      x: Math.random() * w,
      y: Math.random() * h,
      r: Math.random() * 1.4 + 1,
    }));
    draw();
  }

  function draw() {
    ctx.clearRect(0, 0, w, h);
    const linkDist = 130;
    ctx.strokeStyle = "rgba(34, 29, 21, 0.10)";
    ctx.lineWidth = 1;
    for (let i = 0; i < points.length; i++) {
      for (let j = i + 1; j < points.length; j++) {
        const dx = points[i].x - points[j].x, dy = points[i].y - points[j].y;
        const d = Math.sqrt(dx * dx + dy * dy);
        if (d < linkDist) {
          ctx.beginPath();
          ctx.moveTo(points[i].x, points[i].y);
          ctx.lineTo(points[j].x, points[j].y);
          ctx.stroke();
        }
      }
    }
    ctx.fillStyle = "rgba(34, 29, 21, 0.42)";
    for (const p of points) {
      ctx.beginPath();
      ctx.arc(p.x, p.y, p.r, 0, Math.PI * 2);
      ctx.fill();
    }
  }

  resize();
  window.addEventListener("resize", resize);
}

/* ---------- التنقل ---------- */
function initNav() {
  const toggle = document.querySelector(".nav-toggle");
  const nav = document.querySelector(".main-nav");
  if (!toggle || !nav) return;
  toggle.addEventListener("click", () => nav.classList.toggle("open"));
  nav.querySelectorAll("a").forEach(a => a.addEventListener("click", () => nav.classList.remove("open")));
}

/* ---------- ألوان العناصر على البطاقات ---------- */
function initElementColors() {
  document.querySelectorAll("[data-element]").forEach(el => {
    const color = ELEMENT_COLOR[el.dataset.element];
    if (color) el.style.setProperty("--el-color", color);
  });
}

/* ---------- بطاقات القلب (اللمس على الجوال + لوحة المفاتيح) ---------- */
function initFlipCards() {
  document.querySelectorAll(".flip-card").forEach(card => {
    card.addEventListener("click", (e) => {
      if (window.matchMedia("(hover: hover)").matches) return; // الديسكتوب يعتمد على hover
      if (e.target.closest("a")) return;
      card.classList.toggle("flipped");
    });
    card.addEventListener("keydown", (e) => {
      if (e.key !== "Enter" && e.key !== " ") return;
      if (e.target.closest("a")) return;
      e.preventDefault();
      card.classList.toggle("flipped");
    });
  });
}

/* ---------- إمالة ثلاثية الأبعاد عند التحويم ---------- */
function initTilt() {
  const els = document.querySelectorAll(".tilt-target");
  if (!window.matchMedia("(hover: hover)").matches) return;
  els.forEach(el => {
    el.addEventListener("mousemove", (e) => {
      const r = el.getBoundingClientRect();
      const x = (e.clientX - r.left) / r.width - 0.5;
      const y = (e.clientY - r.top) / r.height - 0.5;
      el.style.transform = `perspective(700px) rotateY(${x * 10}deg) rotateX(${-y * 10}deg)`;
    });
    el.addEventListener("mouseleave", () => { el.style.transform = ""; });
  });
}

/* ---------- ظهور تدريجي عند التمرير ---------- */
function initReveal() {
  const items = document.querySelectorAll(".reveal");
  if (!items.length) return;
  const io = new IntersectionObserver((entries) => {
    entries.forEach(en => { if (en.isIntersecting) en.target.classList.add("in"); });
  }, { threshold: 0.15 });
  items.forEach(i => io.observe(i));
}

/* ---------- أداة: اعرف برجك من تاريخ ميلادك ---------- */
function initFinder() {
  const btn = document.getElementById("finderBtn");
  const dateInput = document.getElementById("finderDate");
  const result = document.getElementById("finderResult");
  if (!btn || !dateInput || !result) return;

  btn.addEventListener("click", () => {
    if (!dateInput.value) return;
    const [y, m, d] = dateInput.value.split("-").map(Number);
    const sign = findSignByDate(m, d);
    if (!sign) return;
    result.innerHTML = `
      <div class="glyph" style="color:${ELEMENT_COLOR[sign.element]}">${zodiacIconSvg(sign.slug, 56)}</div>
      <h3>برجك هو ${sign.name}</h3>
      <p>عنصرك ${ELEMENT_NAME[sign.element]} ✦ <a href="${sign.slug}.html" class="btn btn-primary" style="margin-top:10px">اكتشف كل صفات ${sign.name} ←</a></p>
    `;
    result.classList.add("show");
  });
}

/* ---------- أداة: حاسبة توافق الأبراج ---------- */
const ELEMENT_COMPAT = {
  fire:  { fire: 88, air: 82, earth: 46, water: 40 },
  earth: { earth: 85, water: 80, fire: 46, air: 44 },
  air:   { air: 84, fire: 82, water: 50, earth: 44 },
  water: { water: 86, earth: 80, air: 50, fire: 40 },
};

function computeCompat(s1, s2) {
  let base = ELEMENT_COMPAT[s1.element][s2.element];
  if (s1.slug === s2.slug) base = 95;
  else if (s1.quality === s2.quality) base -= 4;
  else base += 2;
  return Math.max(20, Math.min(97, Math.round(base)));
}

function compatText(s1, s2, score) {
  let bucket, phrase;
  if (score >= 82) { bucket = "توافق استثنائي"; phrase = `${s1.name} و${s2.name} يشكلان ثنائياً يفهم بعضه بلا جهد؛ الانسجام بين عنصريكما يجعل الحوار سلساً والطاقة متبادلة بشكل طبيعي.`; }
  else if (score >= 65) { bucket = "توافق جيد"; phrase = `هناك كيمياء واضحة بين ${s1.name} و${s2.name}، مع بعض الاختلافات التي تُغني العلاقة أكثر مما تعرقلها إن وُجد تفاهم وصبر.`; }
  else if (score >= 50) { bucket = "توافق متوسط"; phrase = `يحتاج ${s1.name} و${s2.name} بعض الجهد الواعي للتفاهم؛ الاختلاف في نمط التعامل مع الحياة قد يخلق احتكاكاً لكنه أيضاً فرصة للتعلم المتبادل.`; }
  else { bucket = "علاقة تحدٍ"; phrase = `المسافة بين طبيعتي ${s1.name} و${s2.name} كبيرة، وهذا لا يعني استحالة التفاهم، لكنه يتطلب وعياً حقيقياً بالفروقات واحتراماً صادقاً لاختلاف الإيقاع بينكما.`; }
  return { bucket, phrase };
}

function initCompat() {
  const sel1 = document.getElementById("compatSign1");
  const sel2 = document.getElementById("compatSign2");
  const btn = document.getElementById("compatBtn");
  const result = document.getElementById("compatResult");
  if (!sel1 || !sel2 || !btn || !result) return;

  // ملء القوائم
  [sel1, sel2].forEach((sel, idx) => {
    ZODIAC.forEach(s => {
      const opt = document.createElement("option");
      opt.value = s.slug;
      opt.textContent = s.name;
      sel.appendChild(opt);
    });
  });

  // دعم تحديد مسبق عبر ?sign=slug
  const params = new URLSearchParams(location.search);
  const pre = params.get("sign");
  if (pre && signBySlug(pre)) sel1.value = pre;

  btn.addEventListener("click", () => {
    const s1 = signBySlug(sel1.value), s2 = signBySlug(sel2.value);
    if (!s1 || !s2) return;
    const score = computeCompat(s1, s2);
    const { bucket, phrase } = compatText(s1, s2, score);
    const circumference = 2 * Math.PI * 66;
    const offset = circumference - (score / 100) * circumference;

    result.innerHTML = `
      <div class="score-ring">
        <svg width="150" height="150" viewBox="0 0 150 150">
          <circle class="bg" cx="75" cy="75" r="66"></circle>
          <circle class="fg" cx="75" cy="75" r="66" style="stroke-dasharray:${circumference};stroke-dashoffset:${circumference}"></circle>
        </svg>
        <div class="score-num">${score}%</div>
      </div>
      <h3 style="display:flex;align-items:center;justify-content:center;gap:10px;flex-wrap:wrap">
        <span style="display:flex;align-items:center;gap:6px;color:var(--gold)">${zodiacIconSvg(s1.slug, 26)} ${s1.name}</span>
        ×
        <span style="display:flex;align-items:center;gap:6px;color:var(--gold)">${zodiacIconSvg(s2.slug, 26)} ${s2.name}</span>
        — ${bucket}
      </h3>
      <p style="max-width:520px;margin-inline:auto">${phrase}</p>
    `;
    result.classList.add("show");
    requestAnimationFrame(() => {
      const fg = result.querySelector(".fg");
      if (fg) fg.style.strokeDashoffset = String(offset);
    });
  });
}

/* ---------- الأسئلة الشائعة ---------- */
function initFaq() {
  document.querySelectorAll(".faq-item").forEach(item => {
    const q = item.querySelector(".faq-q");
    if (!q) return;
    q.addEventListener("click", () => {
      const wasOpen = item.classList.contains("open");
      item.parentElement.querySelectorAll(".faq-item").forEach(i => i.classList.remove("open"));
      if (!wasOpen) item.classList.add("open");
    });
  });
}
